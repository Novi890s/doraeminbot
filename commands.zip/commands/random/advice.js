const Command = require('../../structures/Command');
const request = require('node-superfetch');

module.exports = class AdviceCommand extends Command {
	constructor(client) {
		super(client, {
			name: 'advice',
			aliases: ['advice-slip'],
			group: 'random',
			memberName: 'advice',
			description: 'Responds with a random bit of advice.',
			credit: [
				{
					name: 'Advice Slip',
					url: 'https://adviceslip.com/'
				}
			]
		});
	}

	async run(msg) {
		try {
			const { text } = await request.get('http://api.adviceslip.com/advice');
			const body = JSON.parse(text);
			return msg.say(`${body.slip.advice} (#${body.slip.slip_id})`);
		} catch (err) {
			return msg.reply(`Oh no, an error occurred: \`${err.message}\`. Try again later!`);
		}
	}
};
